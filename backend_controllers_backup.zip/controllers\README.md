# Controllers

This folder contains route controllers for handling business logic for each API endpoint (auth, investors, startups, admin, analytics, recommendations, etc.). 