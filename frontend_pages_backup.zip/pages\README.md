# Pages

This folder contains page-level React components (Landing, Registration, Dashboards, Admin Panel, etc.). 

// UserDashboard.jsx — личный кабинет обычного пользователя 